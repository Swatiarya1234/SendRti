package com.example.sendrti.MyRTI.Pakage.tablayouts.tablayoutssubparts.AppliactionProgress.Downloadyourapi;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sendrti.R;

public class Downloadyouapi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_downloadyouapi);
    }
}
