package com.example.sendrti.ui.epf;

import androidx.lifecycle.ViewModel;

public class EpfViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
