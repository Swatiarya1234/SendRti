package com.example.sendrti.ui.Dashboard.AppliactionDetails;

public class ApplicationDetailsViewModel {
}
