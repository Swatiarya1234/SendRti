package com.example.sendrti.EmailQuery;

import androidx.lifecycle.ViewModel;

public class EmailQueryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
