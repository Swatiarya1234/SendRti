package com.example.sendrti.PrefrenceUtil;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.sendrti.R;

public class TypingIndicato extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_typing_indicato);
    }
}
