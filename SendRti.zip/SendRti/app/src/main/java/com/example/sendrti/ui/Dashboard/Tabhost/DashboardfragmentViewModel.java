package com.example.sendrti.ui.Dashboard.Tabhost;


import androidx.lifecycle.ViewModel;

public class DashboardfragmentViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
