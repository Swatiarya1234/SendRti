package com.example.sendrti.Faq;


import androidx.lifecycle.ViewModel;

public class FaqViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
