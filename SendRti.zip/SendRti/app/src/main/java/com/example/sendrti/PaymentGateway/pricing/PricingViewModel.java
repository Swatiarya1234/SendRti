package com.example.sendrti.PaymentGateway.pricing;

import androidx.lifecycle.ViewModel;

public class PricingViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
