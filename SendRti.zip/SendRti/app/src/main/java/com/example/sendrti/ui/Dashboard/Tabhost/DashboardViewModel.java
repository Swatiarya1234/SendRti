package com.example.sendrti.ui.Dashboard.Tabhost;


import androidx.lifecycle.ViewModel;

public class DashboardViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
