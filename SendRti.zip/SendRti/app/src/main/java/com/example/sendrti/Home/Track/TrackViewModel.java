package com.example.sendrti.Home.Track;

import androidx.lifecycle.ViewModel;

public class TrackViewModel extends ViewModel {


    // TODO: Implement the ViewModel
}
