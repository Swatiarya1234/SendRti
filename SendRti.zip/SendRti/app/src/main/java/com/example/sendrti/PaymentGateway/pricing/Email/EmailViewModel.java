package com.example.sendrti.PaymentGateway.pricing.Email;

import androidx.lifecycle.ViewModel;

public class EmailViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
