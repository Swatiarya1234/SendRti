package com.example.sendrti.ui.Incometax;

import androidx.lifecycle.ViewModel;

public class IncomeTaxViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
