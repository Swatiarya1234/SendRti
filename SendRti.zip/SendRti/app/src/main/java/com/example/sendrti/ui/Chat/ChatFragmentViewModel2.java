package com.example.sendrti.ui.Chat;

import androidx.lifecycle.ViewModel;

public class ChatFragmentViewModel2 extends ViewModel {
}
