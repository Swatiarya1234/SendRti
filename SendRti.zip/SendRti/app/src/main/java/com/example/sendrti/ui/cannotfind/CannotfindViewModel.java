package com.example.sendrti.ui.cannotfind;

import androidx.lifecycle.ViewModel;

public class CannotfindViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
