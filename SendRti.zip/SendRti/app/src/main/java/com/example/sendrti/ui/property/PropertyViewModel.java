package com.example.sendrti.ui.property;

import androidx.lifecycle.ViewModel;

public class PropertyViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
