package com.example.sendrti.PrefrenceUtil;

public class PushUtils2 {
}
