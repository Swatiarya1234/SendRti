package com.example.sendrti.ui.marksheet;

import androidx.lifecycle.ViewModel;

public class MarksheetViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
