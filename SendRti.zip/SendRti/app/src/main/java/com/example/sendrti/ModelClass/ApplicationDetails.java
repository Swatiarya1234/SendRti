package com.example.sendrti.ModelClass;

public class ApplicationDetails {
    public String text;
    public ApplicationDetails(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
