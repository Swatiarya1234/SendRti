package com.example.sendrti.ui.Dashboard.pension;

import androidx.lifecycle.ViewModel;

public class PensionViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
