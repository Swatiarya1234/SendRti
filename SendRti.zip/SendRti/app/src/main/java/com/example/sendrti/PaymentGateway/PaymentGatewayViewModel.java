package com.example.sendrti.PaymentGateway;

import androidx.lifecycle.ViewModel;

public class PaymentGatewayViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
