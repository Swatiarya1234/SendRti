package com.example.sendrti.ui.Dashboard.SafeDetails;

import androidx.lifecycle.ViewModel;

public class SafeDetailsViewModel extends ViewModel {
}
