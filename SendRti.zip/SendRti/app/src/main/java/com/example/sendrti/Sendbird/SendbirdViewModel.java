package com.example.sendrti.Sendbird;

import androidx.lifecycle.ViewModel;

public class SendbirdViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
