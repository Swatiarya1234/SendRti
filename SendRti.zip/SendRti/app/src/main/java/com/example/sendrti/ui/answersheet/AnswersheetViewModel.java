package com.example.sendrti.ui.answersheet;

import androidx.lifecycle.ViewModel;

public class AnswersheetViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
