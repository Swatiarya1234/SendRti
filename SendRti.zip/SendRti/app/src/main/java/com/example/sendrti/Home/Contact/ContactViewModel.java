package com.example.sendrti.Home.Contact;

import androidx.lifecycle.ViewModel;

public class ContactViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
