package com.example.sendrti.MyRTI;


import androidx.lifecycle.ViewModel;

public class MyRtiViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
