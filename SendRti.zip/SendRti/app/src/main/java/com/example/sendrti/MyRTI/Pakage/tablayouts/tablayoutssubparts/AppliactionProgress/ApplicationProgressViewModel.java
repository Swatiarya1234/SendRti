package com.example.sendrti.MyRTI.Pakage.tablayouts.tablayoutssubparts.AppliactionProgress;

import androidx.lifecycle.ViewModel;

public class ApplicationProgressViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
