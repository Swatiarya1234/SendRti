package com.example.sendrti.Home.ApplyNow;


import androidx.lifecycle.ViewModel;

public class ApplynowViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
