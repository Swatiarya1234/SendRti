package com.example.sendrti.ui.passport;

import androidx.lifecycle.ViewModel;

public class PassportViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
