package com.example.sendrti.PaymentGateway.pricing.Phone;


import androidx.lifecycle.ViewModel;

public class Phone2ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
