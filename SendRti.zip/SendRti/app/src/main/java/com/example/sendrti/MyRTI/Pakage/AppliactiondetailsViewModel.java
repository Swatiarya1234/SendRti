package com.example.sendrti.MyRTI.Pakage;

import androidx.lifecycle.ViewModel;

public class AppliactiondetailsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
