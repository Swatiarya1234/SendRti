package com.example.sendrti.Notification;

import androidx.lifecycle.ViewModel;

public class NotificationViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
