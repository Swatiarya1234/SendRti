package com.example.sendrti.ui.statusfir;

import androidx.lifecycle.ViewModel;

public class StatusfirViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
