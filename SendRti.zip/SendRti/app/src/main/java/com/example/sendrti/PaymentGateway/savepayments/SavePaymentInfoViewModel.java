package com.example.sendrti.PaymentGateway.savepayments;


import androidx.lifecycle.ViewModel;

public class SavePaymentInfoViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
