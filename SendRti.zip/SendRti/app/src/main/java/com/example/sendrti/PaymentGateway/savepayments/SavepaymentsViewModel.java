package com.example.sendrti.PaymentGateway.savepayments;

import androidx.lifecycle.ViewModel;

public class SavepaymentsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
