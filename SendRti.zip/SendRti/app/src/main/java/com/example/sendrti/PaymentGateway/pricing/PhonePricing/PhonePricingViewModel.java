package com.example.sendrti.PaymentGateway.pricing.PhonePricing;

import androidx.lifecycle.ViewModel;

public class PhonePricingViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
