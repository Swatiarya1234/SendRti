package com.example.sendrti.MyRTI.Pakage.tablayouts.tablayoutssubparts.AppliactionProgress.UplaodRelevantAttachment;


import androidx.lifecycle.ViewModel;

public class ApplicationProgressViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
